# Over the hill: seven paid ad examples (Meta feed, 1080x1350)

Audience: Henderson and Las Vegas vehicle owners. Exclude Boulder City 89005 by name in every ad
set (CALLS-TODO Tier 2c: never buy ads at home). These are EXAMPLES of what a paid campaign would
look like. Nothing here is live. No ad account exists yet (paid-ads readout, section 10).

Facts used: 5.0 stars and 186 Google reviews (public Maps listing, read live 2026-09-24,
re-read before running). Family owned and operated since 1994. Lifetime manufacturer warranty.
Ceramic film blocks up to 99 percent of UV. Computer cut. Nevada legal shades. 20 minutes from
Henderson. Tue to Sat, 9 to 5.

Rules honored: no price, no turnaround, no heat percentage, no competitor, no owner name, no
face, no weekend language, no fine amounts, no emojis, no em dashes. "Free quote" is allowed on
Meta and on social. Call CTAs only on ads scheduled Tue to Fri.

---

## A1. Worth the drive
On-image kicker: HENDERSON TO BOULDER CITY
Headline line 1 (white): WORTH THE
Headline line 2 (gold): 20 MINUTES.
Support: 5.0 stars. 186 Google reviews. One family shop since 1994.
Pills: CERAMIC TINT / LIFETIME WARRANTY / SINCE 1994
CTA bar: FREE QUOTE | TEXT (702) 550-8840

Primary text (Meta):
Twenty minutes over the hill is the difference between a tint shop and the tint shop. BC Glass
and Tint has been the same family in the same Boulder City building since 1994, and 186 Google
reviews average 5.0 stars. Ceramic film, computer cut to your exact glass, cut to the shade
Nevada allows, backed by a lifetime manufacturer warranty. Text (702) 550-8840 for a free quote,
or visit bcglassandtint.com. Open Tuesday to Saturday, 9 to 5.
Headline: Worth the 20 minutes from Henderson
Description: 5.0 stars on 186 Google reviews. Free quote.

## A2. The review count
Kicker: 5.0 STARS ON GOOGLE
Headline 1: 186 PEOPLE
Headline 2: MADE THE DRIVE.
Support: Every one of them left five stars. Read them before you book anywhere.
Pills: 5.0 STARS / 186 REVIEWS / SINCE 1994
CTA bar: FREE QUOTE | BCGLASSANDTINT.COM

Primary text:
A stranger can check one thing about a tint shop before handing over the keys: what the last
hundred customers said. BC Glass and Tint in Boulder City holds 5.0 stars across 186 Google
reviews, and the shop has been family owned and operated since 1994. Twenty minutes from
Henderson. Ceramic tint, computer cut, lifetime manufacturer warranty. Visit
bcglassandtint.com for a free quote or text (702) 550-8840.
Headline: 5.0 stars, 186 reviews, 20 minutes away
Description: Family owned in Boulder City since 1994.

## A3. The legal shade
Kicker: NEVADA LEGAL CERAMIC TINT
Headline 1: CUT TO YOUR CAR.
Headline 2: CUT TO THE LAW.
Support: Computer cut to your glass. 35 percent on the front sides, exactly as Nevada allows.
Pills: COMPUTER CUT / NEVADA LEGAL / LIFETIME WARRANTY
CTA bar: FREE QUOTE | TEXT (702) 550-8840

Primary text:
Nevada allows 35 percent on the front side windows and darker behind the driver. We cut every
piece by computer to your exact glass and to that line, so the fit is factory tight and you are
never explaining your windows to anyone. Ceramic film keeps the cabin cooler and blocks up to 99
percent of UV, with a lifetime manufacturer warranty. BC Glass and Tint, Boulder City, 20
minutes from Henderson. Text (702) 550-8840 for a free quote.
Headline: Nevada legal ceramic tint, computer cut
Description: 35 percent front sides. Lifetime warranty.

## A4. The warranty
Kicker: LIFETIME MANUFACTURER WARRANTY
Headline 1: TINTED ONCE.
Headline 2: BACKED FOR LIFE.
Support: The film carries a lifetime manufacturer warranty. The shop has been here since 1994 to honor it.
Pills: LIFETIME WARRANTY / CERAMIC FILM / SINCE 1994
CTA bar: FREE QUOTE | BCGLASSANDTINT.COM

Primary text:
A warranty is only as good as the shop that is still open to honor it. BC Glass and Tint has
been family owned in Boulder City since 1994, and every film we install carries a lifetime
manufacturer warranty. Ceramic tint, computer cut, 5.0 stars on 186 Google reviews. Twenty
minutes from Henderson. Visit bcglassandtint.com for a free quote or text (702) 550-8840.
Headline: Lifetime warranty from a shop that has been here since 1994
Description: Ceramic tint, computer cut. Free quote.

## A5. The family
Kicker: FAMILY OWNED AND OPERATED
Headline 1: 32 YEARS.
Headline 2: SAME FAMILY. SAME SHOP.
Support: Boulder City since 1994. The people who quote your car are the people who tint it.
Pills: SINCE 1994 / 5.0 STARS / LIFETIME WARRANTY
CTA bar: FREE QUOTE | TEXT (702) 550-8840

Primary text:
Since 1994 the same family has tinted cars in the same Boulder City shop. No franchise, no call
center, no crew that changes every season. Ceramic film, computer cut to your glass, lifetime
manufacturer warranty, and 5.0 stars across 186 Google reviews. Twenty minutes from Henderson,
and worth it. Text (702) 550-8840 for a free quote or visit bcglassandtint.com.
Headline: Family owned in Boulder City since 1994
Description: 20 minutes from Henderson. Free quote.

## A6. The sun
Kicker: CERAMIC WINDOW TINT
Headline 1: THE SUN DOES NOT
Headline 2: STOP AT THE HILL.
Support: Low fall sun comes in flat through the glass. Ceramic film keeps the heat and the UV off the cabin.
Pills: BLOCKS UP TO 99% UV / COOLER CABIN / LIFETIME WARRANTY
CTA bar: FREE QUOTE | TEXT (702) 550-8840

Primary text:
The heat backs off in the fall. The sun does not. It drops lower and comes straight through the
side glass on the drive home. Ceramic tint keeps the cabin cooler and blocks up to 99 percent of
UV, cut to the shade Nevada allows and backed by a lifetime manufacturer warranty. BC Glass and
Tint, family owned in Boulder City since 1994, 20 minutes from Henderson. Text (702) 550-8840
for a free quote.
Headline: Ceramic tint for the low fall sun
Description: Up to 99 percent UV blocked. Lifetime warranty.

## A7. The trip
Kicker: BOULDER CITY, NV
Headline 1: DROP IT OFF
Headline 2: IN BOULDER CITY.
Support: Twenty minutes from Henderson. A shop worth the drive and a town worth the afternoon.
Pills: 20 MIN FROM HENDERSON / 5.0 STARS / SINCE 1994
CTA bar: FREE QUOTE | BCGLASSANDTINT.COM

Primary text:
Make the drive a reason instead of a cost. Drop the car at BC Glass and Tint in Boulder City,
the family shop with 5.0 stars on 186 Google reviews, and spend the time in a town that still has
a downtown. Ceramic tint, computer cut, Nevada legal, lifetime manufacturer warranty. Twenty
minutes from Henderson. Visit bcglassandtint.com for a free quote or text (702) 550-8840. Open
Tuesday to Saturday, 9 to 5.
Headline: Worth the drive to Boulder City
Description: 5.0 stars, 186 reviews. Free quote.

---

## Targeting and measurement note (all seven)

Location: Henderson NV and Las Vegas NV, radius or zip lists. Exclude Boulder City 89005.
Placement: Facebook and Instagram feed. Objective: calls or messages, not form fills.
Season: build and settle before March; May and June are the measured peak.
Measurement: log "how did you hear about us" on every call. Count booked jobs, not calls.
Budget guide from the 2026-08-07 readout: $300 to $500 a month, judged over months, not weeks.
