---
title: BC Glass & Tint - Over the hill batch, message brief
client: bc-glass-and-tint
type: social-brief
status: draft-for-approval
created: 2026-09-24
channel: Instagram and Facebook (7 organic posts) plus Meta paid ad concepts (7 ad posts)
tags: [social, ads, auto-tint, henderson, bloom]
---

# What we are pushing, and why

Chase, 2026-09-24: new car photos in Lightroom, seven social posts and seven paid-ad examples
"to get people coming over the hill." The hill is Railroad Pass. Over it is Henderson, then
Las Vegas. The shop is 11 miles and about 20 minutes from Henderson (area-profile, medium
confidence, usable in copy as "20 minutes").

## The one message

**Worth the drive.** A Henderson driver has a dozen tint shops inside five miles. The only reason
to drive 20 minutes to Boulder City is that the result is better and the shop is the kind of place
you trust with a new car. Every ad answers "why would I drive out there" with a fact the chains
cannot say.

The facts, all verified and all usable on social and in ads (not in a Google post body):

| Fact | Source | Status |
|---|---|---|
| 5.0 stars, 186 Google reviews | Public Google Maps listing, read live 2026-09-24 (no login) | Verified today. Re-read before any later use, it drifts. |
| Family owned and operated since 1994 | 00-READ-FIRST, approved phrasing | Locked |
| Lifetime manufacturer warranty on film | Banned-claims list, APPROVED entry | Locked |
| Ceramic film blocks up to 99 percent of UV | Confirmed manufacturer spec, APPROVED on social and site | OK here, banned in GBP bodies |
| Computer-cut film, factory-style fit | Approved GBP replacement text | Locked |
| Nevada legal shades, 35 percent on front sides | NRS 484D.440, read directly | Locked |
| 20 minutes from Henderson | area-profile henderson.drive_time | Medium confidence, usable |
| Tue to Sat, 9 to 5. Closed Sun and Mon. | 00-READ-FIRST | Locked. No weekend language. |

## The two rules that pull against each other, and the call

1. **The 2026-08-04 geogrid says auto tint's organic reach collapses at 8 to 10 miles**, and the
   valley plan (2026-08-28) says valley-facing work leads with residential film and windshield
   glass, not auto tint. That rule is about ORGANIC map rank.
2. **The 2026-08-07 paid-ads research says the opposite for paid**: auto tint is the one service
   that comfortably pays for ads (about $55 max per lead against roughly $30 real cost), home film
   sits at break-even, and Meta ads are the best fit because they reach people who are not
   searching. Paid geo-targeting does not care what the map pack thinks of an 8-mile query.

**Call: the ad examples lead with auto tint, aimed at Henderson and Las Vegas, and exclude
Boulder City by name.** That is what Chase asked for (the photos are cars) and the paid research
supports it. The organic posts stay on home turf where the shop already wins. Both halves of the
account's own research are respected. The standing "never buy ads targeting Boulder City" rule is
written into every ad's targeting note.

## What the ads are NOT allowed to say

No prices (fourteen services have no recorded price). No "free" is fine here, but no invented
turnaround, no "same day", no "while you wait". No heat-rejection percentage. No competitor
named. No owner name, no faces. No "this weekend". No fine amounts or AS-1 line. No "darker
than legal" hints. No emojis, no em dashes.

## The seven ad angles (paid, Meta, Henderson and Las Vegas only)

| # | Angle | Headline direction | Why it earns the drive |
|---|---|---|---|
| A1 | The distance itself | WORTH THE 20 MINUTES. | Names the objection and answers it with 5.0 / 186. |
| A2 | The review count | 186 PEOPLE DROVE OUT. 5.0 STARS. | Social proof is the only thing a stranger can check. |
| A3 | The legal shade | CUT TO YOUR CAR. CUT TO NEVADA LAW. | Computer cut plus 35 percent front sides. Removes the "will I get pulled over" fear. |
| A4 | The warranty | TINTED ONCE. BACKED FOR LIFE. | Lifetime manufacturer warranty, the chain-beating line. |
| A5 | The family | 32 YEARS. SAME FAMILY. SAME SHOP. | Since 1994. The Green Valley competitor runs "40 years family owned" ads; this is the true version. |
| A6 | The sun | THE SUN DOES NOT STOP AT THE HILL. | Ceramic, up to 99 percent UV, cooler cabin. Low fall sun angle. |
| A7 | The trip | DROP IT IN BOULDER CITY. | Make the drive a reason, not a cost. No duration claim. Text to book. |

Targeting note for all seven: Henderson and Las Vegas zip codes, exclude Boulder City 89005 by
name. Call CTA only on ads scheduled Tue to Fri. Text or website CTA on everything else.
Measure by "how did you hear about us" on the phone (CALLS-TODO item 32), never by call totals.

## The seven social posts (organic, feed 1080x1350)

One photo, one market, one service each. Home turf voice: "the Boulder City shop, in Boulder
City, since 1994." Topics locked after the photos are triaged by pixels, not before.

## Production method

Bloom is the producer (Chase, 2026-08-28). Standing hazards from 08-18 and 09-05 apply:
Bloom re-renders vehicles, upscales reconstruct detail, and every Bloom file carries C2PA.
So: real photo on top, black panel below, Bloom sets the type in the panel, the real photo is
pasted back over Bloom's top half, re-encoded. No raw Bloom file ships. Photo integrity is
measured against the source crop before anything is gated.
